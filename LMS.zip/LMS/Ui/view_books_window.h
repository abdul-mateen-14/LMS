#pragma once
void openViewBooksWindow(bool showBorrowedOnly); // Argument is unused for now
