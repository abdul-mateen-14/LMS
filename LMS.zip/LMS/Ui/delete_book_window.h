#pragma once
void openDeleteBookWindow();

